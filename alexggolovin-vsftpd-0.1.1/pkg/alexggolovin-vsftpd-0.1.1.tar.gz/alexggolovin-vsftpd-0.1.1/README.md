Description:

This is a simple module example which allows deploy and configure vsftpd service for local system users with allowed for download and upload permissions into their own home folders.

To change vsftpd service configurations edit files/local_enabled.conf file.

Note that, only Ubuntu operating system supported.
